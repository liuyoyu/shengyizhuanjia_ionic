import { Component, OnInit } from '@angular/core';
import {LocalStorageService} from '../../services/local-storage.service';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.page.html',
  styleUrls: ['./shop.page.scss'],
})
export class ShopPage implements OnInit {
  shop: any;
  constructor(private localStorageService: LocalStorageService) {
    this.shop = this.localStorageService.get('shop',
      {
        shopName: '',
        shortName: '',
        signup: this.localStorageService.get('signupTime', ''),
        phone: this.localStorageService.get('user', '').accounts[0].identifier,
        email: this. localStorageService.get('user', '').accounts[1].identifier,
        shopKeeperName: '',
        shopTel: ''
      });
  }

  ngOnInit() {

  }

}
