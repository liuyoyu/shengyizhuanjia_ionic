export class Register {
    Id: string;
    ShopName: string;
    Phone: string;
    Email: string;
    CreatDate: string;
    UserID: string;
    Type: number;
    ThridParty: number;
    Identifiter: string;
    PasswordToken: string;
}
