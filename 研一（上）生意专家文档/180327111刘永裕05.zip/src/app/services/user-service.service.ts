import { Injectable } from '@angular/core';
import {LocalStorageService} from './local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private localStorageService: LocalStorageService) { }

  /**
   * 注册，保存用户信息
   * @param {string} phone
   * @param {string} email
   * @param {string} password
   * @param {string} shopname
   * @returns {Boolean}
   */
  signUp(phone: string, email: string, password: string, shopname: string): Boolean {
    const account = this.localStorageService.get('user', '');
    if (account !== '' && (phone == account.accounts[0].identifier || email == account.accounts[1].identifier)) {
      console.log('该账号已经注册过了');
      return false;
    }
    const user = {
      'shopName': shopname,
      'accounts': []
    };
    user.accounts[0] = { identifier: phone, passwordToken: password};
    user.accounts[1] = { identifier: email, passwordToken: password};
    this.localStorageService.set('user', user);
    return true;
  }

  /**
   * 验证登陆
   * @param {string} account
   * @param {string} password
   * @returns {Boolean}
   */
  login(account: string, password: string): boolean {
    const accounts = this.localStorageService.get('user', '').accounts;
    if (!(account == accounts[0].identifier && password == accounts[0].passwordToken)
      && !(account == accounts[1].identifier && password == accounts[1].passwordToken)) {
      return false; // 账号或密码错误
    }
    return true;
  }

}
