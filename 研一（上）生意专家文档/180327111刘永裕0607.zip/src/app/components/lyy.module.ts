import {CommonModule} from "@angular/common";
import {CopyrightComponent} from "./copyright/copyright.component";
import {NgModule} from "@angular/core";

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [CopyrightComponent],
  exports: [CopyrightComponent]
})
export class LyyModule { }