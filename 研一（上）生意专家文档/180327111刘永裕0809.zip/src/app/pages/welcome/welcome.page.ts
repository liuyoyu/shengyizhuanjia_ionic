import {Component, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {NavController, Slides} from '@ionic/angular';
import {LocalStorageService} from '../../services/local-storage.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.page.html',
  styleUrls: ['./welcome.page.scss'],
    encapsulation: ViewEncapsulation.None
})
export class WelcomePage implements OnInit {

    showSkip = false;
    @ViewChild('slides') slides: Slides;
  // constructor() { }

  ngOnInit() {
  }
    onSlideWillChange(event) {
        event.target.isEnd().then((end) => {
            this.showSkip = !end;
        });
    }
    constructor(private localStorageService: LocalStorageService, private router: Router,
                private navCtrl: NavController) {}
    ionViewWillEnter() {
        // 第一次调用get方法时，'App'这个key不存在，第二个参数会作为默认值返回
        let app = this.localStorageService.get('App', {
            hasRun: false,
            version: '1.0.0'
        });
        const appConfig: any = app;
        if ( appConfig.hasRun === false ) {
            appConfig.hasRun = true;
            this.localStorageService.set('App', appConfig);
        } else {
          const current = new Date(+new Date() + 8 * 3600 * 1000).toISOString().replace(/T/g, ' ').replace(/\.[\d]{3}Z/, '').replace(/-/g, '/');
          const loginTime = this.localStorageService.get('loginTime', '1995-10-20 00:00:00').replace(/-/g, '/');
          const sTime = new Date(current); // 开始时间
          const eTime = new Date(loginTime); // 结束时间
          const differ: any = ((sTime.getTime() - eTime.getTime()) / 1000 / 60 / 60).toFixed(0);
          if ( differ - 120 > 0) {
            this.navCtrl.navigateForward('/login');
          } else {
            this.router.navigateByUrl('/home');
          }
        }
    }
    startApplication() {
        // 参考之前的任务通过代码实现页面跳转，登录任务中再完善逻辑//没讲
        this.navCtrl.navigateForward('/home');
    }
}
