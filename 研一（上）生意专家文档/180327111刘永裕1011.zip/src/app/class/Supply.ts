
export class Supply {
  id: string;
  name: string;
  phone: number;
}
