import { Component, OnInit } from '@angular/core';
import {LocalStorageService} from "../../services/local-storage.service";
import {version} from "punycode";
import {NavController} from "@ionic/angular";

@Component({
  selector: 'app-setting',
  templateUrl: './setting.page.html',
  styleUrls: ['./setting.page.scss'],
})
export class SettingPage implements OnInit {

  constructor(private localStorageService: LocalStorageService,
              private navCtrl: NavController) { }
    private version: any = '';

  ngOnInit() {
    const user = this.localStorageService.get('user', '');
    const app = this.localStorageService.get('App', {version: '1.0.0'});
    this.version = app.version;
  }

  /**
   * 拨打电话
   * @param phoneNumber
   */
  // onCall(phoneNumber) {
  //   window.location.href = 'tel:' + phoneNumber;
  // }

  /**
   * 退出当前账号
   */
  onLogout() {
    this.navCtrl.navigateForward('/login');
  }
}
