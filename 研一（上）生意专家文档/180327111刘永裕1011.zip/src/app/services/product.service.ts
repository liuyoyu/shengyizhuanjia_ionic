import { Injectable } from '@angular/core';
import {Product} from '../class/Product';
import {AjaxResult} from '../class/ajax-result';
import {LocalStorageService} from './local-storage.service';
import {UUID} from 'angular2-uuid';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private localStorageService: LocalStorageService) { }

  /**
   * 添加新商品
   * @param {Product} input
   * @returns {Promise<AjaxResult>}
   */
  async insert(input: Product): Promise<AjaxResult>  {
    input.id = UUID.UUID(); // 自动生成ID
    const res = this.localStorageService.get('product', []);
    res.push(input);
    this.localStorageService.set('product', res);
    return {
      targetUrl: '',
      result: res,
      success: true,
      error: null,
      unAuthorizedRequest: false,
    };
  }

  /**
   * ID自增长(不使用）
   * @param {product[]} array
   * @returns {number}
   */
  // autoIncrement(array: Product[]): number {
  //   if (array.length === 0) { return 1; }
  //   const new_id = array[length - 1].id + 1;
  //   return new_id;
  // }

}
